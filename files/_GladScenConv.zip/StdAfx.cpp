/* stdafx.cpp : Source file that just includes standard header.
 *				A file with a .pch extension will be created and this
 *				is the pre compiled header for the project.
 *				This file should not be modified.
 */

#pragma warning(disable : 4786)			// Disable annoying warning about truncation of data in debugging information (caused by string class).

#include "stdafx.h"		// Pre-Compiled Header containing all header data.

#pragma warning(default : 4786)			// Re-Enable the warning to restore normal operation.