// Gladiator Object Code File.

#include "stdafx.h"		// Pre-Compiled Header containing all header data.

// Constructor:
GladObject::GladObject()
{
	Reset();
}

// Complete constructor - sets all variables within the object to their passed values.
GladObject::GladObject(byte NOrder, byte NFamily, short Nxpos, short Nypos, byte NTeam, byte NFacing, byte NCommand, short NLevel, char NName[], char NReserved[])
{
	Order = NOrder;
	Family = NFamily;
	xpos = Nxpos;
	ypos = Nypos;
	Team = NTeam;
	Facing = NFacing;
	Command = NCommand;
	Level = NLevel;
	strcpy(Name, NName);
	strcpy(Reserved, NReserved);
}

GladObject::GladObject(string StringForm)
{
	Reset();		// Make it nice and tidy so that when it is output to file it is nice and tidy.

	// Separators for stringform are ':' between the information part and the data part
	// and the Separator character between items.
	// The Separator character isn't supposed to be usable in Gladiator so it can be
	// used here to find the end of the Name portion without trouble.
	// WARNING: String lines (Name only) may contain those characters, so some extra care
	// needs to be taken on the second last (name) and last (reserved) parts.

	char CForm[MAXDATALENGTH];		// Holds the C form (array) of the string.
	char Extract[50];				// Used to hold data, like numbers, before they are converted to be stored.
	int Locator = 0;				// Location within the array that we are at.
	int ExtractLoc = 0;				// Location within Extract to copy characters to.
	strcpy(CForm, StringForm.c_str());		// Copy out data to array.

	// The separator is displayed correctly in the "Lucidia Console" font, which is the
	// default for Windows 2000 Notepad.  It just happens to be a unicode font, and is char
	// U+00B7 which can be entered with keystroke ALT+0183.
	char Separator = '�';			// Separator Character in text.

	ZeroMemory(Extract, sizeof(Extract));		// Clear.

	// Now we can process it.
	// First up is the Order.
	while(CForm[Locator] != ':') Locator++;		// Move to next ':'
	Locator+=2;		// Move over space after ':'
	while(CForm[Locator] != Separator)
	{
		Extract[ExtractLoc] = CForm[Locator];		// Copy char.
		ExtractLoc++;
		Locator++;
	}
	Locator+=2;		// Jump over the separator and space after it.
	Extract[ExtractLoc] = '\0';		// NULL terminate string for conversion.
	Order = atoi(Extract);			// Convert.
	ExtractLoc = 0;		// Reset Locator.

	// Now the Family:
	while(CForm[Locator] != ':') Locator++;		// Move to next ':'
	Locator+=2;		// Move over ':' and space after it.
	while(CForm[Locator] != Separator)
	{
		Extract[ExtractLoc] = CForm[Locator];		// Copy char.
		ExtractLoc++;
		Locator++;
	}
	Locator+=2;		// Jump over the separator and space after it.
	Extract[ExtractLoc] = '\0';		// NULL terminate string for conversion.
	Family = atoi(Extract);			// Convert.
	ExtractLoc = 0;		// Reset Locator.

	// Now the Xpos:
	while(CForm[Locator] != ':') Locator++;		// Move to next ':'
	Locator+=2;		// Move over ':' and space after it.
	while(CForm[Locator] != Separator)
	{
		Extract[ExtractLoc] = CForm[Locator];		// Copy char.
		ExtractLoc++;
		Locator++;
	}
	Locator+=2;		// Jump over the separator and space after it.
	Extract[ExtractLoc] = '\0';		// NULL terminate string for conversion.
	xpos = atoi(Extract);			// Convert.
	ExtractLoc = 0;		// Reset Locator.

	// Now the Ypos:
	while(CForm[Locator] != ':') Locator++;		// Move to next ':'
	Locator+=2;		// Move over ':' and space after it.
	while(CForm[Locator] != Separator)
	{
		Extract[ExtractLoc] = CForm[Locator];		// Copy char.
		ExtractLoc++;
		Locator++;
	}
	Locator+=2;		// Jump over the separator and space after it.
	Extract[ExtractLoc] = '\0';		// NULL terminate string for conversion.
	ypos = atoi(Extract);			// Convert.
	ExtractLoc = 0;		// Reset Locator.

	// Now the Team:
	while(CForm[Locator] != ':') Locator++;		// Move to next ':'
	Locator+=2;		// Move over ':' and space after it.
	while(CForm[Locator] != Separator)
	{
		Extract[ExtractLoc] = CForm[Locator];		// Copy char.
		ExtractLoc++;
		Locator++;
	}
	Locator+=2;		// Jump over the separator and space after it.
	Extract[ExtractLoc] = '\0';		// NULL terminate string for conversion.
	Team = atoi(Extract);			// Convert.
	ExtractLoc = 0;		// Reset Locator.

	// Now the Facing:
	while(CForm[Locator] != ':') Locator++;		// Move to next ':'
	Locator+=2;		// Move over ':' and space after it.
	while(CForm[Locator] != Separator)
	{
		Extract[ExtractLoc] = CForm[Locator];		// Copy char.
		ExtractLoc++;
		Locator++;
	}
	Locator+=2;		// Jump over the separator and space after it.
	Extract[ExtractLoc] = '\0';		// NULL terminate string for conversion.
	Facing = atoi(Extract);			// Convert.
	ExtractLoc = 0;		// Reset Locator.

	// Now the Command:
	while(CForm[Locator] != ':') Locator++;		// Move to next ':'
	Locator+=2;		// Move over ':' and space after it.
	while(CForm[Locator] != Separator)
	{
		Extract[ExtractLoc] = CForm[Locator];		// Copy char.
		ExtractLoc++;
		Locator++;
	}
	Locator+=2;		// Jump over the separator and space after it.
	Extract[ExtractLoc] = '\0';		// NULL terminate string for conversion.
	Command = atoi(Extract);			// Convert.
	ExtractLoc = 0;		// Reset Locator.

	// Now the Level:
	while(CForm[Locator] != ':') Locator++;		// Move to next ':'
	Locator+=2;		// Move over ':' and space after it.
	while(CForm[Locator] != Separator)
	{
		Extract[ExtractLoc] = CForm[Locator];		// Copy char.
		ExtractLoc++;
		Locator++;
	}
	Locator+=2;		// Jump over the separator and space after it.
	Extract[ExtractLoc] = '\0';		// NULL terminate string for conversion.
	Level = atoi(Extract);			// Convert.
	ExtractLoc = 0;		// Reset Locator.

	// With the special separator the Name is found exactly like the rest:
	while(CForm[Locator] != ':') Locator++;		// Move to next ':'
	Locator+=2;		// Move over ':' and space after it.
	while(CForm[Locator] != Separator)
	{
		Extract[ExtractLoc] = CForm[Locator];		// Copy char.
		ExtractLoc++;
		Locator++;
	}
	Locator+=2;		// Jump over the separator and space after it.
	Extract[ExtractLoc] = '\0';		// NULL terminate string for conversion.
	strcpy(Name, Extract);			// Store
	ExtractLoc = 0;		// Reset Locator.

	// Reserved ends with the separator character.
	while(CForm[Locator] != ':') Locator++;		// Move to next ':'
	Locator+=2;		// Move over ':' and space after it.
	while(CForm[Locator] != Separator)
	{
		Extract[ExtractLoc] = CForm[Locator];		// Copy char.
		ExtractLoc++;
		Locator++;
	}
	Locator+=2;		// Jump over the separator and space after it.
	Extract[ExtractLoc] = '\0';		// NULL terminate string for conversion.
	strcpy(Reserved, Extract);			// Store

	// Done storing.
}

// Destructor:
GladObject::~GladObject()
{
}

// Reset() - Clears object to default values, most of which represent invalid values.
void GladObject::Reset()
{
	Order = -1;
	Family = -1;
	xpos = -1;
	ypos = -1;
	Team = -1;
	Facing = -1;
	Command = -1;
	Level = -1;
	ZeroMemory(Name, sizeof(Name));
	ZeroMemory(Reserved, sizeof(Reserved));
}

// StringForm() - Returns (in StringToFill) a string representation of
// this object, it should be MAXLINELENGTH in size or larger.
void GladObject::StringForm(char StringToFill[])
{
	sprintf(StringToFill, "Order: %hi� Family: %hi� Xpos: %hi� Ypos: %hi� Team: %hi� Facing: %hi� Command: %hi� Level: %hi� Name: %s� Reserved: %s�", Order, Family, xpos, ypos, Team, Facing, Command, Level, Name, Reserved);
}