/* This file contains all the globals to be defined externally so that
 * all files can see and access them easily.
 * Structure definitions should be placed in extglobals.h
 */

#include "stdafx.h"		// Pre-Compiled Header containing all header data.

/* General: */
HINSTANCE hInst;				// Global Instance, set at start of WinMain().
HWND hMainWnd;					// Global Handle to Main Window.
HDC MainWindowDC;				// Device Context to the main window (Do NOT draw directly to).
HDC VirtualWinMemDC;			// Device Contect to a Virtual Window Memory DC, draw everything onto this.
HBITMAP hVirtualBitmap;			// Virtual Bitmap for use with the VirtualWinMemDC, enables drawing.
HBITMAP hOriginalVirtualBitmap;	// Original Virtual Bitmap inside VirtualWinMemDC, used to select out the bitmap we use for safe object deletion.
Logger ProgramLog("ProgramLog.txt");	// Logger object for the program.
HANDLE ProgramMutex;			// Used to ensure that only one instance of the program is active at any one time.

Scenario SingleScenario;		// Single Scenario used during the conversion process.

// Storage for Path and Filenames:
char TextFileAndPath[_MAX_PATH];
char ScenFileAndPath[_MAX_PATH];

// Controls:
HINSTANCE TextSelectFileButtonInstance;
HWND hTextSelectFileButton;
HINSTANCE TextFileEditBoxInstance;
HWND hTextFileEditBox;
HINSTANCE TextProcessButtonInstance;
HWND hTextProcessButton;

HINSTANCE ScenSelectFileButtonInstance;
HWND hScenSelectFileButton;
HINSTANCE ScenFileEditBoxInstance;
HWND hScenFileEditBox;
HINSTANCE ScenProcessButtonInstance;
HWND hScenProcessButton;