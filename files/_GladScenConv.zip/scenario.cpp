// Scenario Object code file for storing a FSS
// (Forgotten Sages Scenario) file in.
// See header file for format and other information.

#include "stdafx.h"		// Pre-Compiled Header containing all header data.

// Constructor:
Scenario::Scenario()
{
	// Initialise or otherwise clear the object to accepted defaults:
	Reset();
}

// Destructor:
Scenario::~Scenario()
{
	// Remove and free all objects in each linked list:
	ObjectList.clear();
	StringList.clear();
}

// Reset() clears all entries in the scenario object to their defaults.
void Scenario::Reset()
{
	ZeroMemory(&Header, sizeof(Header));

	Version = 0;

	ZeroMemory(&GridName, sizeof(GridName));
	
	ZeroMemory(&ScenTitle, sizeof(ScenTitle));

	ScenType = 0;		// 0 is default according to specs.

	ParVal = 0;

	NumObjects = 0;

	ObjectList.clear();		// Clear Object linked List.

	NumLines = 0;

	StringList.clear();		// Clear strings linked list.
}

// Reads in a scenario file, it clears existing data first.
// Returns GetLastError() in most cases, which is a positive number you
// can match to the error list in the SDK.
// Special cases are (And hopefully they don't conflict with the SDK
// - a quick check didn't reveal any negative values returned from GetLastError():
// Failed validating header: -1
// Version number != 8: -2
// Length of a line is > MAXLINELENGTH: -3
DWORD Scenario::ReadInScenarioFile(char FileName[])
{
	Reset();		// Clear existing data from object.

	HANDLE hScenFile = INVALID_HANDLE_VALUE;		// File Handle to scenario file we are reading from.

	hScenFile = CreateFile(FileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if(hScenFile == INVALID_HANDLE_VALUE)
	{
		MessageBox(hMainWnd, "Failed Opening Scenario File", "File Error", MB_OK);			// Notify user about failure.
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	BOOL bReadSuccess = TRUE;			// Stores return value of ReadFile() calls.
	DWORD dwBytesRead = 0;				// Stores number of bytes actually read in, 0 if EOF.

	// Read in header:
	bReadSuccess = ReadFile(hScenFile, &Header, 3, &dwBytesRead, NULL);

	if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
	{
		MessageBox(hMainWnd, "Failed reading Header information from scenario file.", "File Read Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Validate Header:
	Header[3] = '\0';		// Append NULL terminator for comparison to work.
	if(strcmp(Header, "FSS") != 0)
	{
		MessageBox(hMainWnd, "Error: Header does not match \"FSS\", check that you are loading a Gladiator Scenario File.", "File Error", MB_OK);
		CloseHandle(hScenFile);			// Close Handle to file.
		return -1;		// Failed validating header.
	}

	bReadSuccess = ReadFile(hScenFile, &Version, 1, &dwBytesRead, NULL);

	if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
	{
		MessageBox(hMainWnd, "Failed reading version number from scenario file.", "File Read Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Test version - we can only load version 8:
	if(Version != 8)
	{
		MessageBox(hMainWnd, "Invalid Version: Must be version 8", "Bad Version", MB_OK);
		CloseHandle(hScenFile);			// Close Handle to file.
		return -2;			// Invalid Version.
	}

	// Read in Grid Name:
	bReadSuccess = ReadFile(hScenFile, &GridName, 8, &dwBytesRead, NULL);

	if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
	{
		MessageBox(hMainWnd, "Failed reading Grid Name from scenario file.", "File Read Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	GridName[8] = '\0';			// Not much use as a string without terminator...

	// Read Scenario Title, comes with it's own terminator:
	bReadSuccess = ReadFile(hScenFile, &ScenTitle, 30, &dwBytesRead, NULL);

	if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
	{
		MessageBox(hMainWnd, "Failed reading Scenario Title from scenario file.", "File Read Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Read Scenario Type:
	bReadSuccess = ReadFile(hScenFile, &ScenType, 1, &dwBytesRead, NULL);

	if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
	{
		MessageBox(hMainWnd, "Failed reading Scenario Type from scenario file.", "File Read Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}


	// Read Par Value:
	bReadSuccess = ReadFile(hScenFile, &ParVal, 2, &dwBytesRead, NULL);

	if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
	{
		MessageBox(hMainWnd, "Failed reading Par Value from scenario file.", "File Read Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Read Total number of objects:
	bReadSuccess = ReadFile(hScenFile, &NumObjects, 2, &dwBytesRead, NULL);

	if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
	{
		MessageBox(hMainWnd, "Failed reading Number of objects from scenario file.", "File Read Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Read in each object:
	for(int ObjLoop = 0; ObjLoop < NumObjects; ObjLoop++)
	{
		// Object variables, used as temporary storage for read data.
		// These are here so that the file I/O is kept to this object and
		// the GladObject is relegated to only storing data - nothing more.
		byte Order;
		byte Family;
		short xpos;
		short ypos;
		byte Team;
		byte Facing;
		byte Command;
		short Level;
		char Name[11];
		char Reserved[9];

		ZeroMemory(Name, sizeof(Name));
		ZeroMemory(Reserved, sizeof(Reserved));

		// Read object data:
		bReadSuccess = ReadFile(hScenFile, &Order, 1, &dwBytesRead, NULL);

		if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
		{
			MessageBox(hMainWnd, "Failed reading an objects Order value from scenario file.", "File Read Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		bReadSuccess = ReadFile(hScenFile, &Family, 1, &dwBytesRead, NULL);

		if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
		{
			MessageBox(hMainWnd, "Failed reading an objects Family value from scenario file.", "File Read Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		bReadSuccess = ReadFile(hScenFile, &xpos, 2, &dwBytesRead, NULL);

		if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
		{
			MessageBox(hMainWnd, "Failed reading an objects xpos value from scenario file.", "File Read Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		bReadSuccess = ReadFile(hScenFile, &ypos, 2, &dwBytesRead, NULL);

		if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
		{
			MessageBox(hMainWnd, "Failed reading an objects ypos value from scenario file.", "File Read Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		bReadSuccess = ReadFile(hScenFile, &Team, 1, &dwBytesRead, NULL);

		if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
		{
			MessageBox(hMainWnd, "Failed reading an objects Team value from scenario file.", "File Read Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		bReadSuccess = ReadFile(hScenFile, &Facing, 1, &dwBytesRead, NULL);

		if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
		{
			MessageBox(hMainWnd, "Failed reading an objects Facing value from scenario file.", "File Read Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		bReadSuccess = ReadFile(hScenFile, &Command, 1, &dwBytesRead, NULL);

		if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
		{
			MessageBox(hMainWnd, "Failed reading an objects Command value from scenario file.", "File Read Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		bReadSuccess = ReadFile(hScenFile, &Level, 2, &dwBytesRead, NULL);

		if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
		{
			MessageBox(hMainWnd, "Failed reading an objects Level from scenario file.", "File Read Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		bReadSuccess = ReadFile(hScenFile, &Name, 12, &dwBytesRead, NULL);

		if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
		{
			MessageBox(hMainWnd, "Failed reading an objects Name from scenario file.", "File Read Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		bReadSuccess = ReadFile(hScenFile, &Reserved, 10, &dwBytesRead, NULL);

		if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
		{
			MessageBox(hMainWnd, "Failed reading an objects Reserved Data from scenario file.", "File Read Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		Reserved[10] = '\0';		// Place NULL at end, even though this is probably redundant anyway.
		
		const GladObject *SingleObject = new GladObject(Order, Family, xpos, ypos, Team, Facing, Command, Level, Name, Reserved);

		ObjectList.push_back(*SingleObject);		// Place object in list.
	}

	// Get number of text lines to read in:
	bReadSuccess = ReadFile(hScenFile, &NumLines, 1, &dwBytesRead, NULL);

	if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
	{
		MessageBox(hMainWnd, "Failed reading the number of text lines from scenario file.", "File Read Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Read and store text lines:
	for(int TextLoop = 0; TextLoop < NumLines; TextLoop++)
	{
		int NumChars = 0;			// Number of chars on this line, not used aside from the read function as it can be redetermined at any other time once the string is read in.
		char StringData[MAXLINELENGTH];			// Temporary holding array for string data before it is placed into object.
		ZeroMemory(StringData, sizeof(StringData));

		// Read byte for num chars in this line:
		bReadSuccess = ReadFile(hScenFile, &NumChars, 1, &dwBytesRead, NULL);

		if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
		{
			MessageBox(hMainWnd, "Failed reading the number of characters in a line of text.", "File Read Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		if(NumChars > MAXLINELENGTH)
		{
			MessageBox(hMainWnd, "Error: Number of characters on a text line is greater than the maximum line length, and therefore cannot be read, terminating conversion operation.", "Line Length exceeded", MB_OK);
			CloseHandle(hScenFile);
			return -3;
		}

		// Check to see if there are any characters on this line to read in,
		// No chars means Blank line.
		if(NumChars > 0)
		{
			// Read in NumChars bytes that represents the next string:
			bReadSuccess = ReadFile(hScenFile, &StringData, NumChars, &dwBytesRead, NULL);

			if(bReadSuccess == 0 || dwBytesRead == 0)		// Fail if read error or no data in file.
			{
				MessageBox(hMainWnd, "Failed reading a line of text.", "File Read Error", MB_OK);
				DWORD Error = GetLastError();		// Preserve error code.
				CloseHandle(hScenFile);			// Close Handle to file.
				return Error;
			}
		}else

		string ReadString(StringData);		// String which is placed into list.

		StringList.push_back(StringData);		// Place string in list.
	}

	CloseHandle(hScenFile);			// Close Handle to file.

	return 0;		// Success.
}

// Writes out a scenario to the filename specified.
// Behaviour is to overwrite any existing file.
// CHECK: Should I test to see if dwbyteswritten matches the number
// of bytes I wanted to write?
DWORD Scenario::WriteOutScenarioFile(char FileName[])
{
	HANDLE hScenFile = INVALID_HANDLE_VALUE;		// File Handle to scenario file we are reading from.

	hScenFile = CreateFile(FileName, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	if(hScenFile == INVALID_HANDLE_VALUE)
	{
		MessageBox(hMainWnd, "Failed Opening Scenario File to write to.", "File Error", MB_OK);			// Notify user about failure.
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	BOOL bReadSuccess = TRUE;			// Stores return value of ReadFile() calls.
	DWORD dwBytesWritten = 0;			// Stores number of bytes actually read in, 0 if EOF.

	// Write out header:
	if(WriteFile(hScenFile, &Header, 3, &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed writing Header information to scenario file.", "File Write Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Write out version:
	if(WriteFile(hScenFile, &Version, 1, &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed writing version number to scenario file.", "File Write Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Write out Grid Name:
	if(WriteFile(hScenFile, &GridName, 8, &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed writin Grid Name to scenario file.", "File Write Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Write out Scenario Title:
	if(WriteFile(hScenFile, &ScenTitle, 30, &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed writing Scenario Title to scenario file.", "File Write Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Write out Scenario Type:
	if(WriteFile(hScenFile, &ScenType, 1, &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed writing Scenario Type to scenario file.", "File Write Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Write out Par Value:
	if(WriteFile(hScenFile, &ParVal, 2, &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed writing Par Value to scenario file.", "File Write Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Write out Total number of objects:
	if(WriteFile(hScenFile, &NumObjects, 2, &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed writing Number of objects to scenario file.", "File Write Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Setup Iterator:
	list<GladObject>::iterator ObjItr = ObjectList.begin();

	// Write out each object:
	for(int ObjLoop = 0; ObjLoop < NumObjects; ObjLoop++)
	{
		// Get next object:
		GladObject ThisObject = *ObjItr;

		// Write out object data:
		if(WriteFile(hScenFile, &ThisObject.Order, 1, &dwBytesWritten, NULL) == 0)
		{
			MessageBox(hMainWnd, "Failed writing an objects Order value to scenario file.", "File Write Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		if(WriteFile(hScenFile, &ThisObject.Family, 1, &dwBytesWritten, NULL) == 0)
		{
			MessageBox(hMainWnd, "Failed writing an objects Family value to scenario file.", "File Write Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		if(WriteFile(hScenFile, &ThisObject.xpos, 2, &dwBytesWritten, NULL) == 0)
		{
			MessageBox(hMainWnd, "Failed writing an objects xpos value to scenario file.", "File Write Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		if(WriteFile(hScenFile, &ThisObject.ypos, 2, &dwBytesWritten, NULL) == 0)
		{
			MessageBox(hMainWnd, "Failed writing an objects ypos value to scenario file.", "File Write Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		if(WriteFile(hScenFile, &ThisObject.Team, 1, &dwBytesWritten, NULL) == 0)
		{
			MessageBox(hMainWnd, "Failed writing an objects Team value to scenario file.", "File Write Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		if(WriteFile(hScenFile, &ThisObject.Facing, 1, &dwBytesWritten, NULL) == 0)		
		{
			MessageBox(hMainWnd, "Failed writing an objects Facing value to scenario file.", "File Write Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		if(WriteFile(hScenFile, &ThisObject.Command, 1, &dwBytesWritten, NULL) == 0)
		{
			MessageBox(hMainWnd, "Failed writing an objects Command value to scenario file.", "File Write Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		if(WriteFile(hScenFile, &ThisObject.Level, 2, &dwBytesWritten, NULL) == 0)
		{
			MessageBox(hMainWnd, "Failed writing an objects Level to scenario file.", "File Write Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		if(WriteFile(hScenFile, &ThisObject.Name, 12, &dwBytesWritten, NULL) == 0)
		{
			MessageBox(hMainWnd, "Failed writing an objects Name to scenario file.", "File Write Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		if(WriteFile(hScenFile, &ThisObject.Reserved, 10, &dwBytesWritten, NULL) == 0)
		{
			MessageBox(hMainWnd, "Failed writing an objects Reserved Data to scenario file.", "File Write Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}
		
		ObjItr++;		// Move to next object in list.
	}

	// Write out number of text lines:
	if(WriteFile(hScenFile, &NumLines, 1, &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed writing the number of text lines to scenario file.", "File Write Error", MB_OK);
		DWORD Error = GetLastError();		// Preserve error code.
		CloseHandle(hScenFile);			// Close Handle to file.
		return Error;
	}

	// Setup Iterator:
	list<string>::iterator StrItr = StringList.begin();

	// Write out text lines:
	for(int TextLoop = 0; TextLoop < NumLines; TextLoop++)
	{
		string ThisString = *StrItr;

		unsigned int StrLength = ThisString.size();		// For some reason this can't be done directly in the WriteFile Call.

		// Write out num chars in this line, we get the actual number
		// from the length of the string.
		if(WriteFile(hScenFile, &StrLength, 1, &dwBytesWritten, NULL) == 0)
		{
			MessageBox(hMainWnd, "Failed writing the number of characters in a line of text.", "File Write Error", MB_OK);
			DWORD Error = GetLastError();		// Preserve error code.
			CloseHandle(hScenFile);			// Close Handle to file.
			return Error;
		}

		// Check to see if there are any characters on this line to write.
		// No chars means Blank line and nothing written.
		if(StrLength > 0)
		{
			const char *StringData = ThisString.c_str();		// Retrieve pointer to string data.

			// Write out StrLength bytes that represent the next string:
			if(WriteFile(hScenFile, StringData, StrLength, &dwBytesWritten, NULL) == 0)
			{
				MessageBox(hMainWnd, "Failed writing a line of text.", "File Write Error", MB_OK);
				DWORD Error = GetLastError();		// Preserve error code.
				CloseHandle(hScenFile);			// Close Handle to file.
				return Error;
			}
		}

		StrItr++;		// Move to next string.
	}

	CloseHandle(hScenFile);			// Close Handle to file.

	return 0;		// Success.
}
