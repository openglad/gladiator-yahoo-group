// Gladiator Object header file.

// Object, structured as follows:
// 1-byte ORDER
// 1-byte FAMILY
// 2-byte short xpos
// 2-byte short ypos
// 1-byte TEAM
// 1-byte facing
// 1-byte command
// 1-byte level // 2 bytes in version 7+
// 12-bytes name
// ---
// 10 bytes reserved

// Definitions of values for various parts of scenario, supplied by Tom Ricket.

// Orders
#define ORDER_LIVING 0
#define ORDER_WEAPON 1
#define ORDER_TREASURE 2
#define ORDER_GENERATOR 3
#define ORDER_FX 4
#define ORDER_SPECIAL 5
#define ORDER_BUTTON1 6

// The various FAMILY values (there's one set for each order):

// Living familes
#define FAMILY_SOLDIER 0
#define FAMILY_ELF 1
#define FAMILY_ARCHER 2
#define FAMILY_MAGE 3
#define FAMILY_SKELETON 4
#define FAMILY_CLERIC 5
#define FAMILY_FIREELEMENTAL 6
#define FAMILY_FAERIE 7
#define FAMILY_SLIME 8
#define FAMILY_SMALL_SLIME 9
#define FAMILY_MEDIUM_SLIME 10
#define FAMILY_THIEF 11
#define FAMILY_GHOST 12
#define FAMILY_DRUID 13
#define FAMILY_ORC 14
#define FAMILY_BIG_ORC 15
#define FAMILY_BARBARIAN 16
#define FAMILY_ARCHMAGE 17
#define FAMILY_GOLEM 18
#define FAMILY_GIANT_SKELETON 19
#define FAMILY_TOWER1 20

// Weapon families
#define FAMILY_KNIFE 0
#define FAMILY_ROCK 1
#define FAMILY_ARROW 2
#define FAMILY_FIREBALL 3
#define FAMILY_TREE 4
#define FAMILY_METEOR 5
#define FAMILY_SPRINKLE 6
#define FAMILY_BONE 7
#define FAMILY_BLOOD 8
#define FAMILY_BLOB 9
#define FAMILY_FIRE_ARROW 10
#define FAMILY_LIGHTNING 11
#define FAMILY_GLOW 12
#define FAMILY_WAVE 13
#define FAMILY_WAVE2 14
#define FAMILY_WAVE3 15
#define FAMILY_CIRCLE_PROTECTION 16
#define FAMILY_HAMMER 17
#define FAMILY_DOOR 18
#define FAMILY_BOULDER 19

// Treasure families
#define FAMILY_STAIN 0
#define FAMILY_DRUMSTICK 1
#define FAMILY_GOLD_BAR 2
#define FAMILY_SILVER_BAR 3
#define FAMILY_MAGIC_POTION 4
#define FAMILY_INVIS_POTION 5
#define FAMILY_INVULNERABLE_POTION 6
#define FAMILY_FLIGHT_POTION 7
#define FAMILY_EXIT 8
#define FAMILY_TELEPORTER 9
#define FAMILY_LIFE_GEM 10		// generated upon death
#define FAMILY_KEY 11
#define FAMILY_SPEED_POTION 12

// Generator families
#define FAMILY_TENT 0 // skeletons
#define FAMILY_TOWER 1 // mages
#define FAMILY_BONES 2 // ghosts
#define FAMILY_TREEHOUSE 3 // elves :)

// FX families
#define FAMILY_STAIN 0
#define FAMILY_EXPAND 0
#define FAMILY_GHOST_SCARE 1
#define FAMILY_BOMB 2
#define FAMILY_EXPLOSION 3 // Bombs, etc.
#define FAMILY_FLASH 4 // Used for teleporter effects
#define FAMILY_MAGIC_SHIELD 5 // revolving protective shield
#define FAMILY_KNIFE_BACK 6 // Returning blade
#define FAMILY_BOOMERANG 7 // Circling boomerang
#define FAMILY_CLOUD 8 // purple poison cloud
#define FAMILY_MARKER 9 // Marker for Mages Teleport
#define FAMILY_CHAIN 10 // 'Chain lightning' effect
#define FAMILY_DOOR_OPEN 11 // The open door

// Apparent team values (unconfirmed/unchecked):
// 0 is red
// 1 is blue
// 2 is yellow
// 3 is green
// 4 is purple

// Facings:
#define FACE_UP 0
#define FACE_UP_RIGHT 1
#define FACE_RIGHT 2
#define FACE_DOWN_RIGHT 3
#define FACE_DOWN 4
#define FACE_DOWN_LEFT 5
#define FACE_LEFT 6
#define FACE_UP_LEFT 7

// Commands:
#define COMMAND_WALK 1
#define COMMAND_FIRE 2
#define COMMAND_RANDOM_WALK 3 // walk random dir ..
#define COMMAND_DIE 4 // bug fixing ..
#define COMMAND_FOLLOW 5
#define COMMAND_RUSH 6 // Rush your enemy!
#define COMMAND_MULTIDO 7 // Do <com1> commands in one round
#define COMMAND_QUICK_FIRE 8 // Fires with no busy or animation
#define COMMAND_SET_WEAPON 9 // set weapon type
#define COMMAND_RESET_WEAPON 10 // restores weapon to default
#define COMMAND_SEARCH 11 // use right-hand rule to find foe
#define COMMAND_ATTACK 12 // attack / move to a close, current foe
#define COMMAND_RIGHT_WALK 13 // use right-hand rule ONLY; no direct walk
#define COMMAND_UNCHARM 14 // recover from being 'charmed'

class GladObject
{
	// Private Members:
	public:		// Public Members.
		byte Order;
		byte Family;
		short xpos;
		short ypos;
		byte Team;
		byte Facing;
		byte Command;
		short Level;		// Objects level.
		char Name[11];		// Includes Null
		char Reserved[10];	// No NULL written to file, but used for debugging reasons.

		GladObject();		// Default Constructor.
		GladObject(byte NOrder, byte NFamily, short Nxpos, short Nypos, byte NTeam, byte NFacing, byte NCommand, short NLevel, char NName[], char NReserved[]);		// Complete constructor.
		GladObject(string StringForm);		// Creates object with settings from the StringForm, which can be produced from another object or made by hand.
		~GladObject();		// Destructor.
		void Reset(void);	// Resets object to default values.
		void StringForm(char StringToFill[]);		// Returns a single string representing this object.
};
