/* This file contains all the globals defined externally so that
 * all files can see and access them easily.
 * The explanations of what the variables are for is in
 * extglobals.cpp
 */

/* General: */
extern HINSTANCE hInst;
extern HWND hMainWnd;
extern HDC MainWindowDC;
extern HDC VirtualWinMemDC;
extern HBITMAP hVirtualBitmap;
extern HBITMAP hOriginalVirtualBitmap;
extern Logger ProgramLog;
extern HANDLE ProgramMutex;

extern Scenario SingleScenario;

// Storage for Path and Filenames:
extern char TextFileAndPath[_MAX_PATH];
extern char ScenFileAndPath[_MAX_PATH];

// Controls:
extern HINSTANCE TextSelectFileButtonInstance;
extern HWND hTextSelectFileButton;
extern HINSTANCE TextFileEditBoxInstance;
extern HWND hTextFileEditBox;
extern HINSTANCE TextProcessButtonInstance;
extern HWND hTextProcessButton;

extern HINSTANCE ScenSelectFileButtonInstance;
extern HWND hScenSelectFileButton;
extern HINSTANCE ScenFileEditBoxInstance;
extern HWND hScenFileEditBox;
extern HINSTANCE ScenProcessButtonInstance;
extern HWND hScenProcessButton;