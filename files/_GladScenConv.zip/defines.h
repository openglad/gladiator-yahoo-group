/* This file contains all the definitions for the program.
 * You must define all resouce ID's in here (copy and paste from
 * resource.h is the easiest way).
 */

/* Program Definitions: */
#define TEXTFILEEDITBOX 1
#define TEXTFILESELECTBUTTON 2
#define TEXTPROCESSBUTTON 3
#define SCENFILEEDITBOX 4
#define SCENFILESELECTBUTTON 5
#define SCENPROCESSBUTTON 6

#define MAXDATALENGTH 2000		// This should be revised by looking at the specification for optimum file transfer values.