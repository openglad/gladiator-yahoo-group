/* This is the logger class, it's purpose is to log incomming data
 * to a specific log file.
 * All entries are tagged with date and time and are spaced for
 * readability.
 */

// NOTE: There seems to be some issues with it sometimes, I'm not sure what
// but *something* was causing errors.

#include "stdafx.h"		// Pre-Compiled Header containing all header data.


Logger::Logger()
{
	// Invalidate the log file handle so no other functions will attempt to use it until opened:
	LogFile = INVALID_HANDLE_VALUE;

	// Invalidate the handle to the main window so it is not used:
	hProgramMainWindow = NULL;
}

Logger::Logger(char FileName[])
{
	// Invalidate the handle to the main window so it is not used:
	hProgramMainWindow = NULL;

	// If logging is not turned off:
	if(LOGGERACTIVE)
	{
		// Open the requested file, if it fails invalidate the file handle:
		if(!OpenLogFile(FileName)) LogFile = INVALID_HANDLE_VALUE;
	}else LogFile = INVALID_HANDLE_VALUE;
}

Logger::Logger(char FileName[], HWND hWindowHandle)
{
	// Set the window handle to the parameter passed:
	hProgramMainWindow = hWindowHandle;

	// If logging is not turned off:
	if(LOGGERACTIVE)
	{
		// Open the requested file, if it fails invalidate the file handle:
		if(!OpenLogFile(FileName)) LogFile = INVALID_HANDLE_VALUE;
	}else LogFile = INVALID_HANDLE_VALUE;
}

Logger::~Logger()
{
	if(LogFile != INVALID_HANDLE_VALUE) CloseLogFile(true);
}

void Logger::InternalProblem(char Problem[], DWORD dwErrorCode)
{
	/* Parameters:
	 * char Problem[] - A description of the problem.
	 * DWORD dwErrorCode - The code returned from GetLastError()
	 */

	/* This method is internal to the object and is only ever called
	 * when something happens with the loggers operations.
	 * Currently it sends a WM_LOGGERPROBLEM message, defined in
	 * logger.h and it's parameters are wParam as 0 and lParam
	 * containing a string with the problem desription.
	 *
	 * NOTE: If the handle to the programs main window is not given
	 * to the logger will put a MessageBox belonging to the Desktop
	 * up instead.
	 */

	char OutputMessage[3*MAXLOGGERMESSAGELENGTH];
	char ErrorAddition[MAXLOGGERMESSAGELENGTH];

	strcpy(OutputMessage, Problem);

	sprintf(ErrorAddition, "\nError Code: %lu", dwErrorCode);

	strcat(OutputMessage, ErrorAddition);

	if(hProgramMainWindow != NULL)
	{
		if(PostMessage(hProgramMainWindow, WM_LOGGERPROBLEM, 0, (LPARAM)(LPCSTR)OutputMessage) == 0)
		{
			char PostMessageError[MAXLOGGERMESSAGELENGTH];
			sprintf(PostMessageError, "\nAdditionally there was an error with PostMessage, which returned error code %lu", GetLastError());

			strcat(OutputMessage, PostMessageError);

			MessageBox(NULL, OutputMessage, "Logger Error", MB_OK);
		}
	}else MessageBox(NULL, OutputMessage, "Logger Error", MB_OK);
}

bool Logger::OpenLogFile(char FileName[])
{
	DWORD dwLogFileSize;		// Obtains the size of the log file, in case one already exists.
	DWORD dwBytesWritten;		// Number of bytes that WriteFile operations dump into the file.

	LogFile = CreateFile(FileName, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	if(LogFile == INVALID_HANDLE_VALUE)
	{
		InternalProblem("There has been a problem opening or creating the log file.", GetLastError());
		return false;		// Failed.
	}

	// Move to end of file:
	dwLogFileSize = GetFileSize(LogFile, NULL);

	if(dwLogFileSize == 0xFFFFFFFF)
	{
		InternalProblem("There has been a problem determining the file size of the log file.", GetLastError());
		CloseLogFile(false);
		return false;		// Failed.
	}

	if(SetFilePointer(LogFile, dwLogFileSize, NULL, FILE_BEGIN) == 0xFFFFFFFF)
	{
		InternalProblem("There has been a problem moving to the end of the file.", GetLastError());
		CloseLogFile(false);
		return false;		// Failed.
	}

	// Write in a header signaling the start of the logger:
	if(WriteFile(LogFile, "\r\n", strlen("\r\n"), &dwBytesWritten, NULL) ==0)		// Write out a newline.
	{
		InternalProblem("There has been an error writing out some data to the log file.", GetLastError());
		CloseLogFile(false);
		return false;		// Failed.
	}

	LogEntry(DEBUGALWAYS, "Logger Online.");

	return true;		// Success!
}

bool Logger::CloseLogFile(bool WriteFinalEntry)
{
	if(LogFile != INVALID_HANDLE_VALUE)
	{
		if(WriteFinalEntry) LogEntry(DEBUGALWAYS, "Logger Shutting Down.");
		if(CloseHandle(LogFile) == 0)
		{
			InternalProblem("There has been an error while closing the log file.", GetLastError());
			return false;	// There's been a problem, so it probably didn't close.
		}else return true;	// Closed ok.
	}
	return false;		// Log file Handle is invalid, can't close it.
}

void Logger::LogEntry(int DebugLevel, char Message[])
{
	if(LOGGERACTIVE)
	{
		DWORD dwBytesWritten;			// Number of bytes that WriteFile operations dump into the file.
		SYSTEMTIME DateAndTime;		// Stores current date and time information.
		char DateAndTimeOutput[MAXLOGGERMESSAGELENGTH];		// Used to ouput the date and time before a logger entry.

		// Place the date and time on the line before each entry.
		GetLocalTime(&DateAndTime);
		sprintf(DateAndTimeOutput, "\r\nEntered On: %u/%u/%u At %u:%u:%u\r\n", DateAndTime.wDay, DateAndTime.wMonth, DateAndTime.wYear, DateAndTime.wHour, DateAndTime.wMinute, DateAndTime.wSecond);

		if(LogFile != INVALID_HANDLE_VALUE)
		{
			// Only output if specified debug level is lower than highest level.
			if(DebugLevel <= HIGHESTDEBUGLEVEL)
			{
				if(WriteFile(LogFile, DateAndTimeOutput, strlen(DateAndTimeOutput), &dwBytesWritten, NULL) == 0)
				{
					InternalProblem("There has been an error attempting to write out the time and date to the log file.", GetLastError());
					CloseLogFile(false);
				}

				if(WriteFile(LogFile, Message, strlen(Message), &dwBytesWritten, NULL) == 0)
				{
					InternalProblem("There has been an error attempting to write out a log entry to the log file.", GetLastError());
					CloseLogFile(false);
				}

				if(WriteFile(LogFile, "\r\n", strlen("\r\n"), &dwBytesWritten, NULL) == 0)		// Write out a newline.
				{
					InternalProblem("There has been an error attempting to write out a newline to the log file.", GetLastError());
					CloseLogFile(false);
				}
			}
		}
	}
}

void Logger::Error(char Message[])
{
	/* This function is designed to take an error that is 'Fatal' to
	 * the program (that is the program cannot continue) and attempt
	 * to make a clean exit.
	 *
	 * Parameter: char Message[] is the message that will be written
	 * out to the logger file (if possible).
	 */

	DWORD dwBytesWritten;			// Number of bytes that WriteFile operations dump into the file.
	SYSTEMTIME DateAndTime;		// Stores current date and time information.
	char DateAndTimeOutput[MAXLOGGERMESSAGELENGTH];		// Used to ouput the date and time before a logger entry.

	// Place the date and time on the line before each entry.
	GetLocalTime(&DateAndTime);
	sprintf(DateAndTimeOutput, "\r\nAn Error has occured on: %u/%u/%u At %u:%u:%u\r\n", DateAndTime.wDay, DateAndTime.wMonth, DateAndTime.wYear, DateAndTime.wHour, DateAndTime.wMinute, DateAndTime.wSecond);

	// Open the file if logging has been disabled:
	if(!LOGGERACTIVE)
	{
		if(!OpenLogFile("ProgramError.txt")) InternalProblem("Error() failed to open the log file to output the error code.", GetLastError());
	}

	if(LogFile != INVALID_HANDLE_VALUE)
	{
		WriteFile(LogFile, DateAndTimeOutput, strlen(DateAndTimeOutput), &dwBytesWritten, NULL);
		WriteFile(LogFile, Message, strlen(Message), &dwBytesWritten, NULL);
		WriteFile(LogFile, "\r\n", strlen("\r\n"), &dwBytesWritten, NULL);
	}

	// Call the supplied cleanup routine:
	ProgramCleanup();

	ExitProcess(1);		// Close the process with an exit code indicating an error.
}