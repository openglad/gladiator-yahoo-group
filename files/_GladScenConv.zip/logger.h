/* The header file for the logger class, see logger.cpp for more
 * details.
 * The HIGHESTDEBUGLEVEL setting can be used to determine which
 * debugging statements are output, depending on their level.
 * Level 0 are always written out, level 3 will write out anything
 * sent in.
 */

/* Debug Level Definitions: */
#define DEBUGHIGH 3
#define DEBUGMEDIUM 2
#define DEBUGLOW 1
#define DEBUGALWAYS 0

#define LOGGERACTIVE false		// Is the logger active (not being active suppress all normal output).

#define MAXLOGGERMESSAGELENGTH 500		// Maximum Length of a message that logger will output.

#define WM_LOGGERPROBLEM WM_APP + 16000			// The message we use to tell the program that there has been a problem that we can't write to file.
// NOTE: The value for the message is near the end of the usable range and should not conflict with anything a program or the system uses.

#define HIGHESTDEBUGLEVEL DEBUGHIGH			// The highest level of input sent to the logger that will be output to file.

class Logger
{
	// Private Members:
	HANDLE LogFile;		// The Log File we write to.

	void InternalProblem(char Problem[], DWORD dwErrorCode);			// There has been an internal program in the logger.

	public:		// Public Members:
		HWND hProgramMainWindow;		// Handle to the programs main window, if this is not set or is invalid the logger has no way of reporting internal problems it can't write to file.

		Logger();		// Default Constructor.
		Logger(char FileName[]);		// Constructor that automatically opens file for writing.
		Logger(char FileName[], HWND hWindowHandle);	// Primary Constructor to give the logger the window handle to the main window.
		~Logger();		// Destructor.

		bool OpenLogFile(char FileName[]);		// Open a log file, if one is already in use it is closed.
		bool CloseLogFile(bool WriteFinalEntry);					// Closes the Log File currently in use.

		void LogEntry(int DebugLevel, char Message[]);		// Log an entry into the Log File.

		void Error(char Message[]);			// Error processing message, attempts to cleanly exit the program.
};