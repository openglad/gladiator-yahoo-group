// Scenario Object header file for storing a FSS
// (Forgotten Sages Scenario) file.
// File format is as follows (as provided by Tom Ricket):
//
// 3-byte header: 'FSS'
// 1-byte version #
// 8-byte string = grid name to load
// 30-byte scenario title (ver 6+)
// 1-byte char = scenario type, default is 0
// 2-bytes par-value, v.8+
// 2-bytes (short) = total objects to follow
// List of n objects, each of 7-bytes of form:
// 1-byte ORDER
// 1-byte FAMILY
// 2-byte short xpos
// 2-byte short ypos
// 1-byte TEAM
// 1-byte facing
// 1-byte command
// 1-byte level // 2 bytes in version 7+
// 12-bytes name
// ---
// 10 bytes reserved
// 1-byte # of lines of text to load
// List of n lines of text, each of form:
// 1-byte character width of line		--		If 0 there is a blank line, when writing if string length is 0 it's a blank line too.
// m bytes == characters on this line
//
// See gladeditor.txt for expanded descriptions.

#define MAXLINELENGTH 100			// Maximum length of a line of text - arbitrary value plucked from thin air.

class Scenario
{
	// Private Members:

	public:		// Public Members.
		char Header[4];				// Header, supposed to be FSS (no NULL terminator in file) when read in, need to use 4 bytes in storage otherwise strange overwriting things happen when they shouldn't be.
		byte Version;				// Version of scenario, 1 byte.
		char GridName[8];			// Grid Name to load, 8 characters max (no NULL terminator in file).
		char ScenTitle[30];			// Scenario Title, max 30 characters.
		byte ScenType;				// Scenario Type, single bit-flag that indicates how scenario is completed.
		unsigned short ParVal;		// 2-byte Par value (estimate on how fast you should complete level).
		unsigned short NumObjects;	// 2-bytes, total number of objects in scenario.

		list<GladObject> ObjectList;		// LinkedList with objects of type GladObject in them.

		byte NumLines;				// 1-byte, number of lines of text.

		list<string> StringList;			// LinkedList with strings in them.

		Scenario();			// Default constructor.
		~Scenario();		// Destructor.

		void Reset(void);		// Resets values to default.

		DWORD ReadInScenarioFile(char FileName[]);
		DWORD WriteOutScenarioFile(char FileName[]);
};