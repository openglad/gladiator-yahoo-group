/* Gladiator Scenario Converter - Converts Gladiator scenarios to a
 * a text file, or from text to scenario.
 * Created by David Storey.
 * Started on 30/6/2001
 * Exit Codes: 0 ok, 1 Error via Logger, 2 Mutex Already exists.
 */

#include "stdafx.h"		// Pre-Compiled Header containing all header data.

// Flags to prevent EN_CHANGE processing when user picks files via button:
bool ScenFileJustChanged = false;
bool TextFileJustChanged = false;

/* The Main Windows Message Handler/Processor: */
LRESULT CALLBACK MainWindowFunction(HWND hWnd, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch(Message)		/* Message Handling System for Main Window. */
		{
			case WM_COMMAND:
				{
					switch(LOWORD(wParam))
						{
							// Check buttons regarding converting from text file to scenario:
							case TEXTFILESELECTBUTTON:
								{
									switch(HIWORD(wParam))
									{
										case BN_CLICKED:		// Button was clicked.
											{
												OPENFILENAME SelectFile;		// Sent to GetOpenFileName.
												char FileName[_MAX_PATH];		// Contains the FileName the user selected.
												char ProgramDir[_MAX_PATH];		// Contains the Program's Directory.

												// Clear Structures and Strings:
												ZeroMemory(&ProgramDir, sizeof(ProgramDir));
												ZeroMemory(&FileName, sizeof(FileName));
												ZeroMemory(&SelectFile, sizeof(SelectFile));

												if(GetCurrentDirectory(sizeof(ProgramDir), ProgramDir) == 0) ProgramLog.Error("First Select Button: Failed getting current program Directory");

												SelectFile.lStructSize = sizeof(SelectFile);
												SelectFile.hwndOwner = hMainWnd;
												SelectFile.lpstrFilter = "Text Files (*.txt) \0 *.txt;*.TXT \0 All Files (*.*) \0 *.*; \0\0";
												SelectFile.lpstrCustomFilter = NULL;
												SelectFile.nFilterIndex = 1;
												SelectFile.lpstrFile = TextFileAndPath;
												SelectFile.nMaxFile = sizeof(TextFileAndPath);
												SelectFile.lpstrFileTitle = FileName;
												SelectFile.nMaxFileTitle = sizeof(FileName);
												SelectFile.lpstrInitialDir = ProgramDir;
												SelectFile.lpstrTitle = "Select Text File to Convert to Scenario File";
												SelectFile.Flags = OFN_FILEMUSTEXIST;
												SelectFile.lpstrDefExt = "log";

												// Get new filename, only change current one if a new one is selected:
												TextFileJustChanged = true;
												if(GetOpenFileName(&SelectFile))
												{
													if(SendMessage(hTextFileEditBox, WM_SETTEXT, 0, (LPARAM)SelectFile.lpstrFileTitle) != TRUE) ProgramLog.Error("Text File Button: Failed Setting new Filename.");
												}else TextFileJustChanged = false;		// User pressed cancel, so no change.
											}break;
									}
								}break;

							case TEXTPROCESSBUTTON:
								{
									switch(HIWORD(wParam))
									{
										case BN_CLICKED:
											{
												// Process text file, converting to scenario:
												ProcessTextFile(TextFileAndPath, sizeof(TextFileAndPath));
											}break;
									}
								}break;

							case TEXTFILEEDITBOX:
								{
									switch(HIWORD(wParam))
										{
											case EN_CHANGE:		// User changed edit box, we need to get the updated text.
												{
													// If they entered a bad filename it'll be picked up at some point in the future.
													if(!TextFileJustChanged) SendMessage(hTextFileEditBox, WM_GETTEXT, (WPARAM)_MAX_PATH, (LPARAM)TextFileAndPath);
													else TextFileJustChanged = false;
												}break;
										}
								}break;

							// Check buttons regarding converting from scenario to text file:
							case SCENFILESELECTBUTTON:
								{
									switch(HIWORD(wParam))
									{
										case BN_CLICKED:		// Button was clicked.
											{
												OPENFILENAME SelectFile;	// Sent to GetOpenFileName.
												char FileName[_MAX_PATH];			// Contains the FileName the user selected.
												char ProgramDir[_MAX_PATH];		// Contains the Program's Directory.

												// Clear Structures and Strings:
												ZeroMemory(&ProgramDir, sizeof(ProgramDir));
												ZeroMemory(&FileName, sizeof(FileName));
												ZeroMemory(&SelectFile, sizeof(SelectFile));

												if(GetCurrentDirectory(sizeof(ProgramDir), ProgramDir) == 0) ProgramLog.Error("First Select Button: Failed getting current program Directory");

												SelectFile.lStructSize = sizeof(SelectFile);
												SelectFile.hwndOwner = hMainWnd;
												SelectFile.lpstrFilter = "Scenario Files (*.fss) \0 *.fss;*.FSS \0\0";
												SelectFile.lpstrCustomFilter = NULL;
												SelectFile.nFilterIndex = 1;
												SelectFile.lpstrFile = ScenFileAndPath;
												SelectFile.nMaxFile = sizeof(ScenFileAndPath);
												SelectFile.lpstrFileTitle = FileName;
												SelectFile.nMaxFileTitle = sizeof(FileName);
												SelectFile.lpstrInitialDir = ProgramDir;
												SelectFile.lpstrTitle = "Select Log File to Convert";
												SelectFile.Flags = OFN_FILEMUSTEXIST;
												SelectFile.lpstrDefExt = "log";

												// Get new filename, only change current one if a new one is selected:
												ScenFileJustChanged = true;
												if(GetOpenFileName(&SelectFile))
												{
													if(SendMessage(hScenFileEditBox, WM_SETTEXT, 0, (LPARAM)SelectFile.lpstrFileTitle) != TRUE) ProgramLog.Error("Scen File Button: Failed Setting new Filename.");
												}else ScenFileJustChanged = false;		// User pressed cancel, so no change.
											}break;
									}
								}break;

							case SCENPROCESSBUTTON:
								{
									switch(HIWORD(wParam))
									{
										case BN_CLICKED:
											{
												// Process Scenario file, converting to text:
											ProcessScenFile(ScenFileAndPath, sizeof(ScenFileAndPath));
											}break;
									}
								}break;

							case SCENFILEEDITBOX:
								{
									switch(HIWORD(wParam))
										{
											case EN_CHANGE:		// User changed edit box, we need to get the updated text.
												{
													// If they entered a bad filename it'll be picked up at some point in the future.
													if(!ScenFileJustChanged) SendMessage(hScenFileEditBox, WM_GETTEXT, (WPARAM)_MAX_PATH, (LPARAM)ScenFileAndPath);
													else ScenFileJustChanged = false;
												}break;
										}
								}break;

							default:break;
						}
				}return 0;

			case WM_PAINT:		// Code to handle Screen Repainting.
				{
					RECT WindowRect;			// Stores Window Size.
					PAINTSTRUCT MainWindowPaintStruct;		// Used to repaint the screen.

					GetWindowRect(hMainWnd, &WindowRect);

					MainWindowDC = BeginPaint(hMainWnd, &MainWindowPaintStruct);

					// Draw text and other graphics in here.

					BitBlt(MainWindowDC, 0, 0, WindowRect.right, WindowRect.bottom, VirtualWinMemDC, 0, 0, SRCCOPY);

					EndPaint(hMainWnd, &MainWindowPaintStruct);
				}return 0;

			case WM_CREATE:
				{
					MainWindowDC = GetDC(hMainWnd);

					// Setup memory Device Context:
					VirtualWinMemDC = CreateCompatibleDC(MainWindowDC);
					if(VirtualWinMemDC==NULL) ProgramLog.Error("WM_CREATE: Failed Creating VirtualWinMemDC.");

					// Create bitmap for use with VirtualWinMemDC:
					hVirtualBitmap = CreateCompatibleBitmap(MainWindowDC, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));
					if(hVirtualBitmap==NULL) ProgramLog.Error("WM_CREATE: Failed Creating VirtualBitmap.");

					hOriginalVirtualBitmap = (HBITMAP)SelectObject(VirtualWinMemDC, hVirtualBitmap);		// Save original bitmap for use in program termination.

					// Clear the completed VirtualWinMemDC:
					PatBlt(VirtualWinMemDC, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), PATCOPY);

					ReleaseDC(hMainWnd, MainWindowDC);		// Release Device Context - creation finished.
				}return 0;
				
			case WM_CLOSE:		// Begin program termination.
				{
					ProgramCleanup();
				}return 0;

			case WM_DESTROY:
				{
					PostQuitMessage(0);		// Send quit message.
				}return 0;
				
			case WM_LOGGERPROBLEM:
				{
					// This message handles communicating error messages from the logger to the user in the event they can't be written to file.
					MessageBox(hMainWnd, (LPCSTR)lParam, "Internal Logger Problem", MB_OK);
				}return 0;

			default: return DefWindowProc(hWnd, Message, wParam, lParam);	// If we don't process it, let windows process it.
		}
	return 0;
}

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	MSG Msg;	// Message used for processing windows messages (in the 'Message Pump').
	hInst=hInstance;

	// Check if program is already running:
	ProgramMutex = CreateMutex(NULL, TRUE, "GSCActive");
	if(GetLastError() == ERROR_ALREADY_EXISTS)
	{
		ProgramLog.LogEntry(DEBUGALWAYS, "Initialisation: Named Mutex already exists, setting focus to already running program and exiting.");

		// Locate already running program:
		HWND ExistingProgram = FindWindow("GSCClass", "Gladiator Scenario Converter");
		if(ExistingProgram != NULL)
		{
			SetForegroundWindow(ExistingProgram);		// Set users view to existing window.

			ProgramLog.LogEntry(DEBUGALWAYS, "Initialisation: Ignore two failure indications after next log entry, window was not initially created so window-related components cannot be destroyed.");

			ProgramCleanup();
			ExitProcess(2);
		}else ProgramLog.LogEntry(DEBUGALWAYS, "Initialisation: Mutex exists but existing program window does not exist!  Will continue program execution.");
		
	}else ProgramLog.LogEntry(DEBUGMEDIUM, "Initialisation: Named Mutex created.");

	ProgramLog.LogEntry(DEBUGLOW, "Initialisatin: Mutex creation and checking complete.");

	CreateAWindow("GSCClass", "Gladiator Scenario Converter", NULL, NULL);

	// Setup Logger:
	ProgramLog.hProgramMainWindow = hMainWnd;

	// Setup controls: 4 buttons, 2 edit boxes.
	hTextProcessButton = CreateWindow("BUTTON", "Convert to Scenario File", WS_CHILD | WS_BORDER | WS_VISIBLE | BS_PUSHLIKE, 350, 190, 170, 25, hMainWnd, (HMENU)TEXTPROCESSBUTTON, TextProcessButtonInstance, NULL);
	hTextSelectFileButton = CreateWindow("BUTTON", "Select Text File", WS_CHILD | WS_BORDER | WS_VISIBLE | BS_PUSHLIKE, 580, 148, 120, 25, hMainWnd, (HMENU)TEXTFILESELECTBUTTON, TextSelectFileButtonInstance, NULL);
	hTextFileEditBox = CreateWindow("EDIT", "", WS_CHILD | WS_BORDER | WS_VISIBLE, 40, 150, 500, 20, hMainWnd, (HMENU)TEXTFILEEDITBOX, TextFileEditBoxInstance, NULL);
	hScenProcessButton = CreateWindow("BUTTON", "Convert to Text File", WS_CHILD | WS_BORDER | WS_VISIBLE | BS_PUSHLIKE, 350, 290, 150, 25, hMainWnd, (HMENU)SCENPROCESSBUTTON, ScenProcessButtonInstance, NULL);
	hScenSelectFileButton = CreateWindow("BUTTON", "Select Scenario File", WS_CHILD | WS_BORDER | WS_VISIBLE | BS_PUSHLIKE, 580, 248, 150, 25, hMainWnd, (HMENU)SCENFILESELECTBUTTON, ScenSelectFileButtonInstance, NULL);
	hScenFileEditBox = CreateWindow("EDIT", "", WS_CHILD | WS_BORDER | WS_VISIBLE, 40, 250, 500, 20, hMainWnd, (HMENU)SCENFILEEDITBOX, ScenFileEditBoxInstance, NULL);

	// Display the window:
	ShowWindow(hMainWnd, SW_MAXIMIZE);
	UpdateWindow(hMainWnd);

	ProgramLog.LogEntry(DEBUGALWAYS, "Program Initialisation complete, entering message processing loop.");

	// Normal Applications use this Message Handler:
	while(GetMessage(&Msg, NULL, 0, 0))
	{
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}

	ProgramLog.LogEntry(DEBUGALWAYS, "Program Terminating.");

	return Msg.wParam;	// Return exit code to operating system - usually 0.
}

/* CreateAWindow() - Creates an ordinary window.
 * WindowClassName - The name of the Window Class.
 * WindowName - The name of the window, or window title.
 * MenuToUse - The Menu to use, if NULL then no menu will be used.
 * IconToUse - The Icon to use, if NULL then the default icon IDI_APPLICATION will be used.
 */
void CreateAWindow(char WindowClassName[], char WindowName[], char MenuToUse[], char IconToUse[])
{
	WNDCLASSEX WCL;							// Our Window Class for Main Window.

	// Define main window class.
	WCL.cbSize = sizeof(WCL); 

	WCL.hInstance = hInst;					// Handle to this instance.
	WCL.lpszClassName = WindowClassName;	// Window class name.
	WCL.lpfnWndProc = MainWindowFunction;	// Window function.
	WCL.style = 0;							// Default style.

	if(IconToUse==NULL) WCL.hIcon = LoadIcon(NULL, IDI_APPLICATION);		// Use Standard icon if none supplied.
	else WCL.hIcon = LoadIcon(hInst, IconToUse);			// Otherwise, use Icon Defined by User.

	WCL.hIconSm = NULL;									// Small icon - Use one in main icon.
	WCL.hCursor = LoadCursor(NULL, IDC_ARROW);			// Cursor style.

	WCL.lpszMenuName = MenuToUse;	// Menu, works regardless of one being supplied or not (NULL is appropriate value for 'no menu').
	WCL.cbClsExtra = 0;				// No extra information needed.
	WCL.cbWndExtra = 0;				// No extra information needed.

	// Make the window background white:
	WCL.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);

	// Register the window class:
	if(!RegisterClassEx(&WCL)) ProgramLog.Error("Initialisation: Failed Registering Window Class.");

	ProgramLog.LogEntry(DEBUGHIGH, "Window Registered.");

	// Create the Main Window:
	if(!(hMainWnd = CreateWindow(WindowClassName, WindowName, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, HWND_DESKTOP, NULL, hInst, NULL))) ProgramLog.Error("Initialisation: Failed Creating Window."); 

	ProgramLog.LogEntry(DEBUGHIGH, "Window Created.");

	// Set Background display mode to Transparent:
	MainWindowDC = GetDC(hMainWnd);
	if(SetBkMode(MainWindowDC, TRANSPARENT)==0)
	{
		ReleaseDC(hMainWnd, MainWindowDC);
		ProgramLog.Error("Initialisation: Failed Setting Background Mode to Transparent.");
	}

	ReleaseDC(hMainWnd, MainWindowDC);

	ProgramLog.LogEntry(DEBUGMEDIUM, "Window Setup Complete.");
}

/* RedrawScreen() - Call this to get your entire screen redrawn.
 * RedrawBackground - If TRUE, the background is repainted, if FALSE the background is not repainted.
 */
void RedrawScreen(bool RedrawBackground)
{
	InvalidateRect(hMainWnd, NULL, RedrawBackground);
}

void ProgramCleanup()
{
	// Cleans up program, use before exiting!

	ProgramLog.LogEntry(DEBUGALWAYS, "Program Cleanup in progress.");

	// Delete Virtual Window and assocaited components:
	SelectObject(VirtualWinMemDC, hOriginalVirtualBitmap);		// Select in original bitmap.
	if(DeleteObject(hVirtualBitmap) == 0) ProgramLog.LogEntry(DEBUGALWAYS, "ProgramCleanup(): Failed to delete virtual bitmap.");
	if(DeleteDC(VirtualWinMemDC) == 0) ProgramLog.LogEntry(DEBUGALWAYS, "ProgramCleanup(): Failed Deleting VirtualWinMemDC.");

	ReleaseMutex(ProgramMutex);		// Release it, regardless of weather we own it or not - if we don't own it then it has no effect.
	if(CloseHandle(ProgramMutex)==0)
	{
		char BadMutex[50];
		sprintf(BadMutex, "ProgramCleanup(): Closing Handle to mutex failed with error code %lu.", GetLastError()); 

		ProgramLog.LogEntry(DEBUGALWAYS, BadMutex);		
	}

	DestroyWindow(hMainWnd);	// Destroy Main Window.

	ProgramLog.LogEntry(DEBUGALWAYS, "Program Cleanup Completed.");
}

// ProcessTextFile converts a text file (in the format that this
// program generates) into a FSS file.
// It is unlikely that someone could build the text file from scratch
// and that isn't the intention anyway - the intention is just to allow
// modification of existing scenarios.
// If an error occurs during read or write failure an error code is returned.
// This is usually from GetLastError(), but there are some special cases
// for reading of a scenario file - see ReadInScenarioFile() for more info.
// Special Cases for this function (I hope they don't conflict with GetLastError):
// -100 : File opening or other I/O failure at that point.
// -101 : Wrong file version!
DWORD ProcessTextFile(char TextFile[], size_t TFLength)
{
	HANDLE hTextFile = INVALID_HANDLE_VALUE;		// File Handle to the text file we will read from.

	ProgramLog.LogEntry(DEBUGMEDIUM, "ProcessTextFile() called, beggining conversion.");

	// Reset existing data in scenario:
	SingleScenario.Reset();

	// Open the text file for reading:
	hTextFile = CreateFile(TextFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if(hTextFile == INVALID_HANDLE_VALUE)
	{
		MessageBox(hMainWnd, "Failed Opening the text file specified, check that it actually exists.", "File Error", MB_OK);
		ProgramLog.LogEntry(DEBUGHIGH, "ProcessTextFile(): Unknown I/O error (likely file-not-found) when attempting to open the text file containing scenario information.");
		return -100;		// Failed opening file.
	}

	// Now read, process and then write out every line in the input file - one line at a time:
	char InputData[MAXDATALENGTH];		// Stores one chunk of data read in.
	char SingleLine[MAXDATALENGTH];		// Stores the line going in and being processed.
	char Front[MAXDATALENGTH];			// Used to retrieve the front portion of a line, which describes what we need to store.
	char Back[MAXDATALENGTH];			// Used to retrieve the back portion of a line, typically data.
	BOOL bReadSuccess = TRUE;			// Stores return value of ReadFile.
	DWORD dwBytesRead = 1;				// Stores number of bytes actually read in each operation, initially > 0 to enter loop (this has no effect on operation otherwise).

	bool LastCharWasCR = false;			// Flag indicating that last character of a batch of data read in was '\r'
	bool StringFormed = false;			// Flag indicating that the next string has been completely formed.

	bool ReadingObjects = false;		// Flag indicating if we are reading in objects or not.
	int ObjectsStored = 0;				// Number of objects we have stored so far.
	bool ReadingStrings = false;		// Flag indicating if we are reading in strngs or not.
	bool ReadPreStringsSpacer = false;	// Flag indicating if we have read the spacer between "Text Lines" and the actual start of the lines.

	ZeroMemory(SingleLine, sizeof(SingleLine));		// Clear Single Line.

	// Setup settings for first string:
	int SingleLineLocation = 0;		// Index of location single line for copy sequence.

	while(bReadSuccess &&  dwBytesRead != 0)
	{
		ZeroMemory(InputData, sizeof(InputData));

		// Read next chunk of characters, fill entire array:
		bReadSuccess = ReadFile(hTextFile, &InputData, MAXDATALENGTH+1, &dwBytesRead, NULL);

		if(!bReadSuccess) ProgramLog.LogEntry(DEBUGLOW, "ProcessTextFile(): Failed reading data from file.");

		// If read was successful (actually read something) continue processing.
		if(dwBytesRead != 0)
		{
			// We probably have more than one line in what we read, so split them out one by one.
			// Incomplete lines are carried over to next read.

			for(int Location = 0; Location <= MAXDATALENGTH; Location++)
			{
				// Check that if we are at the end of the data this char isn't the first half of the \r\n pair:
				if(Location == MAXDATALENGTH && InputData[Location] == '\r')
				{
					LastCharWasCR = true;		// Set flag.
					continue;					// Skip rest of for loop to avoid processing.
				}

				// Check that if we are at the start of the data this char isn't the second half of the \r\n pair:
				if(Location == 0 && LastCharWasCR)
				{
					StringFormed = true;
					LastCharWasCR = false;		// Reset flag.
				}

				// Check if this char and the next char are a \r\n pair indicating end of a line,
				// that a string hasn't already been formed and that we are not at the end of the data set (Location == MAXDATALENGTH)
				// which otherwises causes the last char to be skipped (No Location+1 to check):
				if(InputData[Location] != '\r' && (InputData[Location+1] != '\n' || Location == MAXDATALENGTH) && !StringFormed)
				{
					SingleLine[SingleLineLocation] = InputData[Location];		// Copy character.
					SingleLineLocation++;
				}else StringFormed = true;
					
				if(StringFormed)
				{
					// New string has been completely formed/extracted, process it.
					SingleLine[SingleLineLocation] = '\0';		// Append NULL to end of character sequence, done here it removes the /r/n at the end of the line.

					// Ignore Blank lines, but only if we are not reading strings, since blank lines can be text strings in game:
					if(SingleLine[0] == '\0' && !ReadingStrings)
					{
						ZeroMemory(SingleLine, sizeof(SingleLine));		// Clear the character.
						Location++;		// Increment an extra place.
						SingleLineLocation = 0;
						StringFormed = false;
						continue;
					}

					// Ignore the two information lines:
					if(strcmp(SingleLine, "List of Objects:") == 0)
					{
						ZeroMemory(SingleLine, sizeof(SingleLine));		// Clear the character.
						Location++;		// Increment an extra place.
						SingleLineLocation = 0;
						ReadingObjects = true;		// Set flag.
						StringFormed = false;
						continue;
					}
					if(strcmp(SingleLine, "Text Lines:") == 0)
					{
						ZeroMemory(SingleLine, sizeof(SingleLine));		// Clear the character.
						Location++;		// Increment an extra place.
						SingleLineLocation = 0;
						ReadingStrings = true;
						StringFormed = false;
						continue;
					}

					// Store the new data appropriately:
					if(ReadingObjects)		// No need to split line for objects.
					{
						// Store this object:
						GladObject *NewObject = new GladObject(SingleLine);
						SingleScenario.ObjectList.push_back(*NewObject);		// Place in list.
						ObjectsStored++;
						ZeroMemory(SingleLine, sizeof(SingleLine));		// Clear the character.
						Location++;		// Increment an extra place.
						SingleLineLocation = 0;
						if(ObjectsStored >= SingleScenario.NumObjects) ReadingObjects = false;		// Clear flag once all objects read.
						continue;		// Jump to next iteration.
					}

					if(ReadingStrings)
					{
						// Store this string:
						if(ReadPreStringsSpacer)
						{
							string *ThisString = new string(SingleLine);
							SingleScenario.StringList.push_back(*ThisString);
						}else ReadPreStringsSpacer = true;		// The first time the code goes through here is on the spacer, so flag that it's been processed.

						ZeroMemory(SingleLine, sizeof(SingleLine));		// Clear the character.
						Location++;		// Increment an extra place.
						SingleLineLocation = 0;
						StringFormed = false;
						// No need to check number of stored strings, as code will run out before all are read.
						// Last one is read outside loop.
						continue;		// Jump to next iteration.
					}

					SplitLine(SingleLine, Front, Back, sizeof(Front), sizeof(Back));

					if(strcmp(Front, "Header") == 0) strcpy(SingleScenario.Header, Back); 
					else if(strcmp(Front, "Version") == 0)
					{
						SingleScenario.Version = atoi(Back);
						if(SingleScenario.Version != 8)
						{
							MessageBox(hMainWnd, "Conversion Error: Invalid scenario version in text file, must be version 8.", "Invalid Version", MB_OK);
							ProgramLog.LogEntry(DEBUGMEDIUM, "ProcessTextFile(): Invalid scenario version, terminating conversion process.");
							return -101;
						}
					}
					else if(strcmp(Front, "Grid Name") == 0) strcpy(SingleScenario.GridName, Back);
					else if(strcmp(Front, "Title") == 0) strcpy(SingleScenario.ScenTitle, Back);
					else if(strcmp(Front, "Scenario Type") == 0)
							{
								Back[1] = '\0';		// In text file scenario type has information after it, and we don't want that, the flag can only be a single char and that will be the first one in the array.
								SingleScenario.ScenType = atoi(Back);
							}
					else if(strcmp(Front, "Par Value") == 0) SingleScenario.ParVal = atoi(Back);
					else if(strcmp(Front, "Number of Objects") == 0) SingleScenario.NumObjects = atoi(Back);
					else if(strcmp(Front, "Number of Text Lines") == 0) SingleScenario.NumLines = atoi(Back);

					ZeroMemory(SingleLine, sizeof(SingleLine));			// Clear the now written Single Line.
					Location ++;		// Increment an extra place.

					// Reset SingleLine for next line:
					SingleLineLocation = 0;		// Index of location single line for copy sequence, starts 2 chars up.

					StringFormed = false;		// Reset Flag.
				}
			}

		}
	}

	// Process Last Line, this HAS to be the blank /r/n line or the Number of lines of text (which would be 0 anyway):
	if(ReadingStrings)
	{
		// It's a text line, well actually just /r/n so ignore it.:
	}else
		{
			SplitLine(SingleLine, Front, Back, sizeof(Front), sizeof(Back));
			SingleScenario.NumLines = atoi(Back);		// This *Should* be 0.
		}

	ProgramLog.LogEntry(DEBUGMEDIUM, "ProcessTextFile(): Text file read in successfully, preparing to write out scenario file.");

	// Prepare the new filename:
	char NewScenFileName[_MAX_PATH];
	strcpy(NewScenFileName, TextFile);		// Copy current filename and path for new file.

	// Modify the new filename such that .txt is replaced with .fss:
	int Insert = strlen(NewScenFileName);		// Find Last index of string.
	Insert -= 3;		// Go back 3 places to the 't'
	NewScenFileName[Insert] = 'f';
	NewScenFileName[Insert+1] = 's';
	NewScenFileName[Insert+2] = 's';

	// Write out scenario file (overwrites any existing one):
	DWORD Result = SingleScenario.WriteOutScenarioFile(NewScenFileName);
	if(Result != 0)
	{
		ProgramLog.LogEntry(DEBUGALWAYS, "ProcessTextFile(): Failed Writing out scenario file.");
		return Result;
	}

	MessageBox(hMainWnd, "Conversion Complete!", "Success", MB_OK);

	CloseHandle(hTextFile);			// Close Handle to text file we read from.

	ProgramLog.LogEntry(DEBUGMEDIUM, "ProcessTextFile(): Conversion Completed Successfully.");

	return 0;		// Success.
}

// SplitLine() splits up a line into two halves, the first half
// contains all text up to (but not including) the ':' that marks the break
// between information and actual data.
// The Back half contains the rest of the line, not including the ':' and space right after it.
// NOTE: Front and Back are modified during this call, but Line isn't.
void SplitLine(char Line[], char Front[], char Back[], size_t FLen, size_t BLen)
{
	// The separator for the two halves is a ':'
	char Separator = ':';
	int Location = 0;		// Location we are at in Line.
	int OriginalLength = 0;		// Need this for getting Back easily.
	char LineCopy[MAXDATALENGTH];		// Used for copy of Line.

	// Clear Strings:
	ZeroMemory(Front, FLen);
	ZeroMemory(Back, BLen);
	ZeroMemory(LineCopy, sizeof(LineCopy));

	strcpy(LineCopy, Line);		// Copy Line.

	OriginalLength = strlen(LineCopy);		// Get length of first line.

	for(; LineCopy[Location] != ':' && Location <= strlen(LineCopy); Location++) ;  // Empty, just loops to find ':'

	LineCopy[Location] = '\0';		// NULL terminate the first half.

	Location+=2;		// Jump over space.

	strcpy(Front, LineCopy);		// Copy the first half in.

	// Shuffle the second half back to the start of the array.
	for(int Copy = 0; OriginalLength - Location > 0; Copy++)
	{
		Back[Copy] = LineCopy[Location];
		Location++;
	}

	Back[Copy] = '\0';		// Append NULL.
}

// ProcessScenFile converts a scenario (.FSS) file to a .txt file.
// For now it will OVERWRITE any exiting text file of the same name!
// Text file just has .txt in place of .fss in the filename.
// If an error occurs during read or write failure an error code is returned.
// This is usually from GetLastError(), but there are some special cases
// for reading of a scenario file - see ReadInScenarioFile() for more info.
// Special Cases for this function (I hope they don't conflict with GetLastError):
// -100 : File opening or other I/O failure at that point.
DWORD ProcessScenFile(char ScenFile[], size_t SFLength)
{
	HANDLE hNewTextFile = INVALID_HANDLE_VALUE;		// File Handle to the new text file we create.

	ProgramLog.LogEntry(DEBUGMEDIUM, "ProcessScenFile() called, beggining conversion.");

	// Read in scenario file (Scenario object resets itself for this, no need for external reset):
	DWORD ScenarioResult = SingleScenario.ReadInScenarioFile(ScenFile);
	if(ScenarioResult != 0)
	{
		ProgramLog.LogEntry(DEBUGALWAYS, "ProcessScenFile(): Failed Reading in scenario.");
		return ScenarioResult;
	}

	char NewTextFileName[_MAX_PATH];
	strcpy(NewTextFileName, ScenFile);		// Copy current filename and path for new file.

	// Modify the new filename such that .fss is replaced with .txt:
	int Insert = strlen(NewTextFileName);		// Find Last index of string.
	Insert -= 3;		// Go back 3 places to the 'f'
	NewTextFileName[Insert] = 't';
	NewTextFileName[Insert+1] = 'x';
	NewTextFileName[Insert+2] = 't';

	// POSSIBLE CHANGE: Modify overwrite behaviour by modifying CreateFile call.
	hNewTextFile = CreateFile(NewTextFileName, GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	if(hNewTextFile == INVALID_HANDLE_VALUE)
	{
		MessageBox(hMainWnd, "Failed Opening or Creating the Text File the scenario would be placed in.", "File Error", MB_OK);
		ProgramLog.LogEntry(DEBUGHIGH, "ProcessScenFile(): Unknown I/O error when attempting to open or create the new text file.");
		return -100;		// Failed opening file.
	}

	ProgramLog.LogEntry(DEBUGHIGH, "ProcessScenFile(): New text file opened or created and scenario file read sucessfully, starting actual conversion.");

	// Start writing out text file:
	BOOL bReadSuccess = TRUE;			// Stores return value of ReadFile.
	DWORD dwBytesRead = 0;				// Stores number of bytes actually read in each operation.

	char OutputLine[MAXDATALENGTH];		// Stores a line to be written out to file.
	ZeroMemory(OutputLine, sizeof(OutputLine));

	DWORD dwBytesWritten = 0;		// Bytes written out to new file.

	// Write Header:
	sprintf(OutputLine, "Header: %s\r\n", SingleScenario.Header);

	if(WriteFile(hNewTextFile, OutputLine, strlen(OutputLine), &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed Writing out Header", "File Writing Failure", MB_OK);
		ProgramLog.LogEntry(DEBUGLOW, "ProcessScenFile(): Failed writing out scenario header.");
		DWORD ErrorCode = GetLastError();		// Preserve Error code.
		CloseHandle(hNewTextFile);
		return ErrorCode;
	}

	// Write out version:
	sprintf(OutputLine, "Version: %hi\r\n", SingleScenario.Version);

	if(WriteFile(hNewTextFile, OutputLine, strlen(OutputLine), &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed Writing out Version", "File Writing Failure", MB_OK);
		ProgramLog.LogEntry(DEBUGLOW, "ProcessScenFile(): Failed writing out scenario version.");
		DWORD ErrorCode = GetLastError();		// Preserve Error code.
		CloseHandle(hNewTextFile);
		return ErrorCode;
	}

	// Write out Grid Name:
	sprintf(OutputLine, "Grid Name: %s\r\n", SingleScenario.GridName);

	if(WriteFile(hNewTextFile, OutputLine, strlen(OutputLine), &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed Writing out Grid Name", "File Writing Failure", MB_OK);
		ProgramLog.LogEntry(DEBUGLOW, "ProcessScenFile(): Failed writing out scenario Grid Name.");
		DWORD ErrorCode = GetLastError();		// Preserve Error code.
		CloseHandle(hNewTextFile);
		return ErrorCode;
	}

	// Write out Title:
	sprintf(OutputLine, "Title: %s\r\n", SingleScenario.ScenTitle);

	if(WriteFile(hNewTextFile, OutputLine, strlen(OutputLine), &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed Writing out Title", "File Writing Failure", MB_OK);
		ProgramLog.LogEntry(DEBUGLOW, "ProcessScenFile(): Failed writing out scenario Title.");
		DWORD ErrorCode = GetLastError();		// Preserve Error code.
		CloseHandle(hNewTextFile);
		return ErrorCode;
	}

	// Write out Scenario Type:
	if(SingleScenario.ScenType == 0) sprintf(OutputLine, "Scenario Type: %hi (Kill all Monsters)\r\n", SingleScenario.ScenType);
	if(SingleScenario.ScenType == 1) sprintf(OutputLine, "Scenario Type: %hi (Players can always exit)\r\n", SingleScenario.ScenType);
	if(SingleScenario.ScenType == 2) sprintf(OutputLine, "Scenario Type: %hi (Must kill generators)\r\n", SingleScenario.ScenType);
	if(SingleScenario.ScenType == 4) sprintf(OutputLine, "Scenario Type: %hi (Players must save NPC's / NPC's can't die)\r\n", SingleScenario.ScenType);

	if(WriteFile(hNewTextFile, OutputLine, strlen(OutputLine), &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed Writing out Scenario Type", "File Writing Failure", MB_OK);
		ProgramLog.LogEntry(DEBUGLOW, "ProcessScenFile(): Failed writing out scenario Type.");
		DWORD ErrorCode = GetLastError();		// Preserve Error code.
		CloseHandle(hNewTextFile);
		return ErrorCode;
	}

	// Write out Par Value:
	sprintf(OutputLine, "Par Value: %hi\r\n", SingleScenario.ParVal);

	if(WriteFile(hNewTextFile, OutputLine, strlen(OutputLine), &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed Writing out Par Value", "File Writing Failure", MB_OK);
		ProgramLog.LogEntry(DEBUGLOW, "ProcessScenFile(): Failed writing out scenario Par Value.");
		DWORD ErrorCode = GetLastError();		// Preserve Error code.
		CloseHandle(hNewTextFile);
		return ErrorCode;
	}

	// Write out Number of Objects:
	sprintf(OutputLine, "Number of Objects: %hi\r\n", SingleScenario.NumObjects);

	if(WriteFile(hNewTextFile, OutputLine, strlen(OutputLine), &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed Writing out Number of Objects", "File Writing Failure", MB_OK);
		ProgramLog.LogEntry(DEBUGLOW, "ProcessScenFile(): Failed writing out Number of Objects in Scenario.");
		DWORD ErrorCode = GetLastError();		// Preserve Error code.
		CloseHandle(hNewTextFile);
		return ErrorCode;
	}

	// Write out object list header:
	sprintf(OutputLine, "\r\nList of Objects:\r\n");

	if(WriteFile(hNewTextFile, OutputLine, strlen(OutputLine), &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed Writing out Object List Header", "File Writing Failure", MB_OK);
		ProgramLog.LogEntry(DEBUGLOW, "ProcessScenFile(): Failed writing out Objects List Header.");
		DWORD ErrorCode = GetLastError();		// Preserve Error code.
		CloseHandle(hNewTextFile);
		return ErrorCode;
	}

	list<GladObject>::iterator ItrObjList = SingleScenario.ObjectList.begin();		// Iterator to run over the lists following.

	// Write out data in each object:
	for(int ObjLoop = 0; ObjLoop < SingleScenario.NumObjects; ObjLoop++)
	{
		GladObject CurrentObject = (GladObject)*ItrObjList;		// Retrieve this object.
		CurrentObject.StringForm(OutputLine);		// Retrieve string form of object.
		strcat(OutputLine, "\r\n");		// Append Newline.

		// Actually write it out:
		if(WriteFile(hNewTextFile, OutputLine, strlen(OutputLine), &dwBytesWritten, NULL) == 0)
		{
			MessageBox(hMainWnd, "Failed Writing out an objects data", "File Writing Failure", MB_OK);
			ProgramLog.LogEntry(DEBUGLOW, "ProcessScenFile(): Failed writing out an objects data.");
			DWORD ErrorCode = GetLastError();		// Preserve Error code.
			CloseHandle(hNewTextFile);
			return ErrorCode;
		}

		ItrObjList++;		// Increment Pointer.
	}

	// Write out number of text lines:
	sprintf(OutputLine, "\r\nNumber of Text Lines: %hi\r\n", SingleScenario.NumLines);

	if(WriteFile(hNewTextFile, OutputLine, strlen(OutputLine), &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed Writing out Number of Text Lines", "File Writing Failure", MB_OK);
		ProgramLog.LogEntry(DEBUGLOW, "ProcessScenFile(): Failed writing out Number of Lines of Text in Scenario.");
		DWORD ErrorCode = GetLastError();		// Preserve Error code.
		CloseHandle(hNewTextFile);
		return ErrorCode;
	}

	// Write out header for lines of text:
	sprintf(OutputLine, "\r\nText Lines:\r\n\r\n");

	if(WriteFile(hNewTextFile, OutputLine, strlen(OutputLine), &dwBytesWritten, NULL) == 0)
	{
		MessageBox(hMainWnd, "Failed Writing out header for lines of text.", "File Writing Failure", MB_OK);
		ProgramLog.LogEntry(DEBUGLOW, "ProcessScenFile(): Failed writing out header for lines of text.");
		DWORD ErrorCode = GetLastError();		// Preserve Error code.
		CloseHandle(hNewTextFile);
		return ErrorCode;
	}

	// Write out lines of text:
	list<string>::iterator ItrStrList = SingleScenario.StringList.begin();		// Set Iterator to start of String List.
	for(int StrLoop = 0; StrLoop < SingleScenario.NumLines; StrLoop++)
	{
		string CurrentString = (string)*ItrStrList;

		strcpy(OutputLine, CurrentString.c_str());
		strcat(OutputLine, "\r\n");		// Append newline.

		// Actually write it out:
		if(WriteFile(hNewTextFile, OutputLine, strlen(OutputLine), &dwBytesWritten, NULL) == 0)
		{
			MessageBox(hMainWnd, "Failed Writing out a string", "File Writing Failure", MB_OK);
			ProgramLog.LogEntry(DEBUGLOW, "ProcessScenFile(): Failed writing out a string.");
			DWORD ErrorCode = GetLastError();		// Preserve Error code.
			CloseHandle(hNewTextFile);
			return ErrorCode;
		}

		ItrStrList++;		// Move to next string in list.
	}

	MessageBox(hMainWnd, "Conversion Complete!", "Success", MB_OK);

	CloseHandle(hNewTextFile);			// Close Handle to text file we create.

	ProgramLog.LogEntry(DEBUGMEDIUM, "ProcessScenFile(): Conversion Completed Successfully.");

	return 0;		// Success.
}