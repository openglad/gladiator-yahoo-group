Dancing Corpse Multi-player

	This is a multi player map for two players: green and yellow. Green is attacking yellow's castle.   At the moment I think Green has the advantage but I haven't play tested fairly. This is not the finished product. After I get enough feed back I will change it and repost.

	This milti-player is different from the ones the game comes with because your people are only lvl 1 while the npcs are level 3 so your people are among the least important in the level.

	You need the password you got when you registered gladiator to get into the zip. My e-mail is dancing_corpse@hotmail.com . and thank you to Tevildo for creating the column tiles I use in the yellow castle.
Have fun!
